SET NAMES utf8mb4;
CREATE TABLE users (userid INT PRIMARY KEY, firstname VARCHAR(255), lastname VARCHAR(255), email VARCHAR(255), password_hash TEXT) CHARACTER SET utf8mb4;
INSERT INTO users VALUES (1,'Alice','Smith','alice@example.invalid','SECRET_NEVER_EXPORT'),(2,'Renée','Martin','renee@example.invalid','SECRET_NEVER_EXPORT');
CREATE TABLE experiments (id INT PRIMARY KEY, userid INT, team INT, title VARCHAR(255), date DATE, body MEDIUMTEXT, elabid VARCHAR(255), content_type TINYINT, state INT, metadata JSON, created_at DATETIME, modified_at DATETIME) CHARACTER SET utf8mb4;
CREATE TABLE items (id INT PRIMARY KEY, userid INT, team INT, title VARCHAR(255), date DATE, body MEDIUMTEXT, elabid VARCHAR(255), content_type TINYINT, state INT, metadata JSON, created_at DATETIME, modified_at DATETIME) CHARACTER SET utf8mb4;
CREATE TABLE experiments_templates (id INT PRIMARY KEY, userid INT, team INT, title VARCHAR(255), date DATE, body MEDIUMTEXT, elabid VARCHAR(255), content_type TINYINT, state INT, metadata JSON, created_at DATETIME, modified_at DATETIME) CHARACTER SET utf8mb4;
CREATE TABLE items_types (id INT PRIMARY KEY, userid INT, team INT, title VARCHAR(255), date DATE, body MEDIUMTEXT, elabid VARCHAR(255), content_type TINYINT, state INT, metadata JSON, created_at DATETIME, modified_at DATETIME) CHARACTER SET utf8mb4;
INSERT INTO experiments VALUES (1,1,1,'Attachment recovery','2026-10-08','<h2>Objective</h2><p>Recover the <strong>original attachments</strong> without eLabFTW.</p><h2>Method</h2><p>Incubate at 37 °C. Sample: α-2.</p><table><thead><tr><th>Sample</th><th>Concentration</th></tr></thead><tbody><tr><td>A</td><td>12.5 mM</td></tr><tr><td>B</td><td>8.0 mM</td></tr></tbody></table><h2>Image</h2><img src="app/download.php?f=ab/abcdef01.png" alt="Synthetic microscopy image">','demo-exp-1',1,1,'{"extra_fields": {"Temperature": {"value": "37", "unit": "\\u00b0C"}}}','2026-10-08 07:00:00','2026-10-08 08:00:00');
INSERT INTO experiments VALUES (2,2,1,'Archived Markdown experiment','2026-10-08','## Results

**Yield:** 81%.

| Sample | Yield |
| --- | --- |
| A | 81% |','demo-exp-2',2,2,NULL,'2026-10-08 07:00:00','2026-10-08 08:00:00');
INSERT INTO experiments VALUES (3,1,1,'Deleted experiment','2026-10-08','<p>This soft-deleted entry is included by default.</p>','demo-exp-3',1,3,NULL,'2026-10-08 07:00:00','2026-10-08 08:00:00');
INSERT INTO experiments VALUES (4,17,1,'Experiment with unknown owner','2026-10-08','<p>The owner is missing from the users table.</p>','demo-exp-4',1,1,NULL,'2026-10-08 07:00:00','2026-10-08 08:00:00');
INSERT INTO items VALUES (1,2,1,'Shared instrument','2026-10-08','<p>Resource or template instructions.</p>','demo-items',1,1,NULL,'2026-10-08 07:00:00','2026-10-08 08:00:00');
INSERT INTO experiments_templates VALUES (1,2,1,'PCR template','2026-10-08','<p>Resource or template instructions.</p>','demo-experiments_templates',1,1,NULL,'2026-10-08 07:00:00','2026-10-08 08:00:00');
CREATE TABLE uploads (id INT PRIMARY KEY, real_name TEXT, long_name TEXT, item_id INT, userid INT, type VARCHAR(255), state INT, storage INT, filesize BIGINT, comment TEXT, KEY entity_uploads (item_id,type)) CHARACTER SET utf8mb4;
INSERT INTO uploads VALUES (1,'Microscopy image.png','ab/abcdef01.png',1,1,'experiments',1,1,36593,'Synthetic test attachment');
INSERT INTO uploads VALUES (2,'notes.txt','cd/cdef0002.txt',1,1,'experiments',1,1,20,'Synthetic test attachment');
INSERT INTO uploads VALUES (3,'notes.txt','de/de000003.txt',1,1,'experiments',1,1,21,'Synthetic test attachment');
INSERT INTO uploads VALUES (4,'Measurements.csv','ef/ef000004.csv',1,2,'items',1,1,20,'Synthetic test attachment');
INSERT INTO uploads VALUES (5,'record.html','fa/fa000005.html',1,2,'items',1,1,58,'Synthetic test attachment');
INSERT INTO uploads VALUES (6,'reagent.dat','legacyhash.bin',2,2,'experiments',1,1,22,'Synthetic test attachment');
INSERT INTO uploads VALUES (7,'deleted experiment.txt','aa/aa000007.txt',3,1,'experiments',1,1,25,'Synthetic test attachment');
INSERT INTO uploads VALUES (8,'archived.txt','bb/bb000008.txt',1,1,'experiments',2,1,21,'Synthetic test attachment');
INSERT INTO uploads VALUES (9,'unlinked.txt','cc/cc000009.txt',999,1,'items',1,1,26,'Synthetic test attachment');
INSERT INTO uploads VALUES (10,'Template instructions.txt','dd/dd000010.txt',1,2,'experiments_templates',1,1,23,'Synthetic test attachment');
INSERT INTO uploads VALUES (11,'deleted attachment.txt','ee/ee000011.txt',1,1,'experiments',3,1,25,'Synthetic test attachment');
CREATE TABLE tags (id INT PRIMARY KEY, tag VARCHAR(255));
INSERT INTO tags VALUES (1, 'demo');
CREATE TABLE tags2entity (id INT PRIMARY KEY, item_id INT, tag_id INT, item_type VARCHAR(255));
INSERT INTO tags2entity VALUES (1,1,1,'experiments');
CREATE TABLE experiments_steps (id INT PRIMARY KEY, item_id INT, body TEXT, ordering INT, finished INT, deadline DATETIME);
INSERT INTO experiments_steps VALUES (1,1,'Prepare samples',1,1,NULL);
CREATE TABLE config (conf_name VARCHAR(255), conf_value TEXT);
INSERT INTO config VALUES ('smtp_password', 'SECRET_NEVER_EXPORT');
